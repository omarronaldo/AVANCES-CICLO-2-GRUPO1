package pe.edu.upeu.CalcFx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalcFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
